# 🧠 Age and Gender Detection using Machine Learning

This project uses classical machine learning techniques and computer vision to detect age group and gender from human facial images.

## 📌 Features
- Gender classification (Male/Female)
- Age group classification (e.g., 0-2, 4-6, 8-12, 15-20, etc.)
- Trained with open datasets and evaluated using accuracy, F1-score, and confusion matrix

## 📁 Project Structure
- `dataset/` – Contains data or links to dataset preparation scripts
- `models/` – Saved machine learning models
- `notebooks/` – Jupyter notebooks for EDA and training
- `src/` – Python scripts (data preprocessing, training, evaluation, prediction)
- `results/` – Graphs, confusion matrices, evaluation reports

## 🛠️ How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Prepare dataset and run training:
   ```bash
   python src/train.py
   ```
3. Run prediction:
   ```bash
   python src/predict.py --image_path path_to_image.jpg
   ```

## 📚 Dataset
You can use the UTKFace or Adience dataset. Add download links and instructions in `dataset/README.md`.

## 🤖 Models Used
- SVM
- KNN
- Random Forest
- Logistic Regression
- Optionally, integrate with CNN using TensorFlow or PyTorch for improved performance.

## 🔍 Evaluation Metrics
- Accuracy
- Confusion Matrix
- Precision, Recall, F1-Score

---
Made with ❤️ for ML learning projects.