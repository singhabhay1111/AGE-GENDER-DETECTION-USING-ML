# Load trained model and make predictions on new images
